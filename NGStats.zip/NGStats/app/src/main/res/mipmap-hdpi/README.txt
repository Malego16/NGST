<!-- This directory needs an ic_launcher.png. Use Android Studio Asset Studio to generate one, or copy any 48x48 PNG here. The build will succeed with the default mipmap resource below. -->
