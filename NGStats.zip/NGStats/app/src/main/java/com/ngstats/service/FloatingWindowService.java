package com.ngstats.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ngstats.R;
import com.ngstats.model.AudioEntry;
import com.ngstats.model.StatsCalculator;
import com.ngstats.parser.NgParser;
import com.ngstats.ui.AudioAdapter;
import com.ngstats.ui.MainActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingWindowService extends Service {

    private static final String CHANNEL_ID   = "ngstats_channel";
    private static final int    NOTIF_ID     = 1001;

    private WindowManager   wm;
    private View            floatView;
    private AudioAdapter    adapter;
    private List<AudioEntry> allEntries = new ArrayList<>();
    private ExecutorService executor   = Executors.newSingleThreadExecutor();
    private Handler         mainHandler = new Handler(Looper.getMainLooper());

    // UI refs
    private EditText  etUrl;
    private Spinner   spYear;
    private Button    btnFetch, btnApply, btnMinimize;
    private TextView  tvSummary, tvStatus;
    private ProgressBar progressBar;
    private RecyclerView recycler;
    private LinearLayout llFilters, llColumns;
    private CheckBox cbViews, cbScore, cbComments, cbGenre, cbYear;
    private View     cardExpanded;

    // drag state
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        showFloatingWindow();
    }

    private void showFloatingWindow() {
        if (!Settings.canDrawOverlays(this)) return;

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatView = LayoutInflater.from(this).inflate(R.layout.layout_floating, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        wm.addView(floatView, params);
        bindViews(params);
    }

    private void bindViews(WindowManager.LayoutParams params) {
        etUrl       = floatView.findViewById(R.id.et_url);
        spYear      = floatView.findViewById(R.id.sp_year);
        btnFetch    = floatView.findViewById(R.id.btn_fetch);
        btnApply    = floatView.findViewById(R.id.btn_apply);
        btnMinimize = floatView.findViewById(R.id.btn_minimize);
        tvSummary   = floatView.findViewById(R.id.tv_summary);
        tvStatus    = floatView.findViewById(R.id.tv_status);
        progressBar = floatView.findViewById(R.id.progress_bar);
        recycler    = floatView.findViewById(R.id.recycler);
        llFilters   = floatView.findViewById(R.id.ll_filters);
        cardExpanded= floatView.findViewById(R.id.card_expanded);
        cbViews     = floatView.findViewById(R.id.cb_views);
        cbScore     = floatView.findViewById(R.id.cb_score);
        cbComments  = floatView.findViewById(R.id.cb_comments);
        cbGenre     = floatView.findViewById(R.id.cb_genre);
        cbYear      = floatView.findViewById(R.id.cb_year);

        adapter = new AudioAdapter();
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);

        // Allow typing in EditText (re-enable focus when touching input)
        etUrl.setOnTouchListener((v, e) -> {
            params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            wm.updateViewLayout(floatView, params);
            v.performClick();
            return false;
        });

        // Drag the window by the header bar
        View dragHandle = floatView.findViewById(R.id.drag_handle);
        dragHandle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x; initialY = params.y;
                    initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                    // re-enable focus remove
                    params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    wm.updateViewLayout(floatView, params);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int)(event.getRawX() - initialTouchX);
                    params.y = initialY + (int)(event.getRawY() - initialTouchY);
                    wm.updateViewLayout(floatView, params);
                    return true;
            }
            return false;
        });

        // Minimize / expand toggle
        btnMinimize.setOnClickListener(v -> {
            boolean visible = cardExpanded.getVisibility() == View.VISIBLE;
            cardExpanded.setVisibility(visible ? View.GONE : View.VISIBLE);
            btnMinimize.setText(visible ? "▼" : "▲");
        });

        // Fetch button
        btnFetch.setOnClickListener(v -> {
            String raw = etUrl.getText().toString().trim();
            String username = extractUsername(raw);
            if (username.isEmpty()) {
                Toast.makeText(this, "Введите ссылку на профиль Newgrounds", Toast.LENGTH_SHORT).show();
                return;
            }
            fetchData(username);
        });

        // Apply filter button
        btnApply.setOnClickListener(v -> applyFilters());

        // Column checkboxes → immediately update adapter
        View.OnClickListener colToggle = v -> updateColumns();
        cbViews.setOnClickListener(colToggle);
        cbScore.setOnClickListener(colToggle);
        cbComments.setOnClickListener(colToggle);
        cbGenre.setOnClickListener(colToggle);
        cbYear.setOnClickListener(colToggle);

        // Sort header clicks
        floatView.findViewById(R.id.header_title).setOnClickListener(
                v -> adapter.sortBy(AudioAdapter.SortColumn.TITLE));
        floatView.findViewById(R.id.header_views).setOnClickListener(
                v -> adapter.sortBy(AudioAdapter.SortColumn.VIEWS));
        floatView.findViewById(R.id.header_score).setOnClickListener(
                v -> adapter.sortBy(AudioAdapter.SortColumn.SCORE));
        floatView.findViewById(R.id.header_comments).setOnClickListener(
                v -> adapter.sortBy(AudioAdapter.SortColumn.COMMENTS));
        floatView.findViewById(R.id.header_year).setOnClickListener(
                v -> adapter.sortBy(AudioAdapter.SortColumn.YEAR));
    }

    // -----------------------------------------------------------------------
    private void fetchData(String username) {
        setLoading(true, "Загрузка данных…");
        allEntries.clear();

        executor.submit(() -> {
            try {
                List<AudioEntry> entries = NgParser.fetchAll(username, msg ->
                        mainHandler.post(() -> tvStatus.setText(msg)));

                mainHandler.post(() -> {
                    allEntries.addAll(entries);
                    populateYearSpinner();
                    applyFilters();
                    setLoading(false, "Загружено треков: " + entries.size());
                });
            } catch (Exception ex) {
                mainHandler.post(() -> setLoading(false, "Ошибка: " + ex.getMessage()));
            }
        });
    }

    private void populateYearSpinner() {
        List<Integer> years = StatsCalculator.distinctYears(allEntries);
        List<String> items = new ArrayList<>();
        items.add("Все годы");
        for (int y : years) items.add(String.valueOf(y));
        ArrayAdapter<String> sa = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, items);
        sa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spYear.setAdapter(sa);
    }

    private void applyFilters() {
        int selectedYear = 0;
        if (spYear.getSelectedItemPosition() > 0) {
            try { selectedYear = Integer.parseInt(spYear.getSelectedItem().toString()); }
            catch (Exception ignored) {}
        }

        List<AudioEntry> filtered = StatsCalculator.filterByYear(allEntries, selectedYear);
        StatsCalculator.Summary sum = StatsCalculator.compute(filtered);

        tvSummary.setText(
                "Треков: "         + sum.trackCount
              + "  |  Просмотров: "  + sum.totalViews
              + "  |  Avg ★: "       + String.format("%.2f", sum.avgScore)
              + "  |  Комм: "        + sum.totalComments
              + (sum.topTitle != null
                    ? "\nТоп: " + sum.topTitle + " (" + sum.topViews + " views)" : "")
        );

        updateColumns();
        adapter.setData(filtered);
    }

    private void updateColumns() {
        adapter.showViews    = cbViews.isChecked();
        adapter.showScore    = cbScore.isChecked();
        adapter.showComments = cbComments.isChecked();
        adapter.showGenre    = cbGenre.isChecked();
        adapter.showYear     = cbYear.isChecked();
        adapter.notifyDataSetChanged();
    }

    private void setLoading(boolean loading, String status) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnFetch.setEnabled(!loading);
        tvStatus.setText(status);
    }

    private String extractUsername(String input) {
        // Accept "malego16", "malego16.newgrounds.com", "https://malego16.newgrounds.com/audio"
        input = input.trim()
                .replaceAll("https?://", "")
                .replaceAll("\\.newgrounds\\.com.*", "")
                .replaceAll("/.*", "")
                .trim();
        return input;
    }

    // -----------------------------------------------------------------------
    @Override public void onDestroy() {
        super.onDestroy();
        if (wm != null && floatView != null) wm.removeView(floatView);
        executor.shutdownNow();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    // -----------------------------------------------------------------------
    private void createNotificationChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "NGStats Overlay",
                NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Floating window service");
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, FloatingWindowService.class);
        stopIntent.setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("NGStats активен")
                .setContentText("Плавающее окно статистики")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .addAction(android.R.drawable.ic_delete, "Закрыть", pi)
                .setOngoing(true)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
        }
        return START_STICKY;
    }
}
