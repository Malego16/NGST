package com.ngstats.parser;

import com.ngstats.model.AudioEntry;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses a Newgrounds user audio page.
 * Newgrounds renders all audio items in <li class="item"> blocks grouped
 * under <h2> year headings.  The "Load More" button triggers an AJAX call
 * to /{user}/audio/page/{n} — we follow those pages until exhausted.
 */
public class NgParser {

    private static final String BASE = "https://%s.newgrounds.com/audio";
    private static final String PAGE = "https://%s.newgrounds.com/audio/page/%d";
    private static final int    TIMEOUT_MS = 15_000;

    public interface ProgressCallback {
        void onProgress(String message);
    }

    /**
     * Fetch ALL audio entries for the given username, following pagination.
     */
    public static List<AudioEntry> fetchAll(String username, ProgressCallback cb)
            throws IOException {

        List<AudioEntry> all = new ArrayList<>();
        int page = 1;

        while (true) {
            String url = (page == 1)
                    ? String.format(BASE, username)
                    : String.format(PAGE, username, page);

            if (cb != null) cb.onProgress("Загрузка страницы " + page + "…");

            Document doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Android 13; Mobile) AppleWebKit/537.36")
                    .timeout(TIMEOUT_MS)
                    .get();

            List<AudioEntry> pageEntries = parsePage(doc);
            if (pageEntries.isEmpty()) break;
            all.addAll(pageEntries);

            // Check if "Load More" / next page exists
            Element loadMore = doc.selectFirst("a.load-more-items, .pagination-next a, a[href*='/audio/page/']");
            if (loadMore == null) break;

            page++;
            if (page > 50) break; // safety cap
        }

        return all;
    }

    // -----------------------------------------------------------------------
    // Parse one HTML document into AudioEntry list
    // -----------------------------------------------------------------------
    private static List<AudioEntry> parsePage(Document doc) {
        List<AudioEntry> entries = new ArrayList<>();

        // Year groups: <div class="year-unit"> or <h2> tags
        // Newgrounds groups items with a header like <h2>2023</h2> followed by <ul> of items
        // We track the current year as we walk top-level children.

        int currentYear = 0;
        Pattern yearPattern = Pattern.compile("\\b(20\\d{2}|19\\d{2})\\b");

        // Try structured year blocks first
        Elements yearBlocks = doc.select("div.audio-block, section.year-section");
        if (!yearBlocks.isEmpty()) {
            for (Element block : yearBlocks) {
                Element h = block.selectFirst("h2, h3");
                if (h != null) {
                    Matcher m = yearPattern.matcher(h.text());
                    if (m.find()) currentYear = Integer.parseInt(m.group());
                }
                entries.addAll(parseItems(block.select("li.item, div.portal-item"), currentYear));
            }
        } else {
            // Fallback: walk all children of main content
            Element main = doc.selectFirst("#content, .content-inner, main, #portal-list");
            if (main == null) main = doc.body();

            for (Element child : main.children()) {
                String tag = child.tagName();
                if (tag.equals("h2") || tag.equals("h3")) {
                    Matcher m = yearPattern.matcher(child.text());
                    if (m.find()) currentYear = Integer.parseInt(m.group());
                } else {
                    // items directly or inside ul/div
                    Elements items = child.select("li.item, div.portal-item, li[class*=item]");
                    if (items.isEmpty() && (tag.equals("li") || child.hasClass("item"))) {
                        items = new Elements(child);
                    }
                    entries.addAll(parseItems(items, currentYear));
                }
            }

            // Last resort: grab ALL items on page
            if (entries.isEmpty()) {
                Elements items = doc.select("li.item, div.portal-item, li[class*=item]");
                entries.addAll(parseItems(items, currentYear));
            }
        }

        return entries;
    }

    /**
     * Parse individual item elements into AudioEntry objects.
     * Newgrounds item HTML (simplified):
     *
     * <li class="item">
     *   <div class="detail-title"><h4><a href="/audio/listen/...">Title</a></h4><strong>Genre</strong></div>
     *   <div class="detail-stats">
     *     <dd><abbr title="Views">1,234</abbr></dd>
     *     <dd><abbr title="Score">4.12</abbr></dd>
     *     <dd><abbr title="Reviews">5</abbr></dd>
     *   </div>
     * </li>
     */
    private static List<AudioEntry> parseItems(Elements items, int year) {
        List<AudioEntry> list = new ArrayList<>();
        for (Element item : items) {
            try {
                AudioEntry e = parseItem(item, year);
                if (e != null) list.add(e);
            } catch (Exception ignored) {}
        }
        return list;
    }

    private static AudioEntry parseItem(Element item, int year) {
        // Title
        Element titleEl = item.selectFirst("h4 a, .detail-title a, a.title-link, strong a");
        if (titleEl == null) titleEl = item.selectFirst("a[href*='/audio/listen/']");
        if (titleEl == null) return null;
        String title = titleEl.text().trim();
        String url   = titleEl.absUrl("href");

        // Type & Genre
        String type  = "";
        String genre = "";
        Element typeEl  = item.selectFirst(".type, .item-type, span.type");
        Element genreEl = item.selectFirst(".genre, .item-genre, span.genre, strong");
        if (typeEl  != null) type  = typeEl.text().trim();
        if (genreEl != null) genre = genreEl.text().trim();

        // Stats: views, score, comments
        int   views    = 0;
        float score    = 0f;
        int   comments = 0;

        // Try <abbr title="Views">1,234</abbr> pattern
        Elements abbrs = item.select("abbr");
        for (Element abbr : abbrs) {
            String titleAttr = abbr.attr("title").toLowerCase();
            String val       = abbr.text().replaceAll("[^\\d.]", "");
            if (titleAttr.contains("view"))   views    = parseIntSafe(val);
            else if (titleAttr.contains("score")) score = parseFloatSafe(val);
            else if (titleAttr.contains("review") || titleAttr.contains("comment")) comments = parseIntSafe(val);
        }

        // Fallback: text-based patterns like "1,234 Views"
        if (views == 0) {
            String text = item.text();
            Matcher mv = Pattern.compile("([\\d,]+)\\s*[Vv]iew").matcher(text);
            if (mv.find()) views = parseIntSafe(mv.group(1).replace(",", ""));
            Matcher ms = Pattern.compile("([\\d.]+)\\s*/\\s*5|Score[:\\s]+([\\d.]+)").matcher(text);
            if (ms.find()) score = parseFloatSafe(ms.group(1) != null ? ms.group(1) : ms.group(2));
            Matcher mc = Pattern.compile("([\\d,]+)\\s*[Rr]eview|([\\d,]+)\\s*[Cc]omment").matcher(text);
            if (mc.find()) comments = parseIntSafe((mc.group(1) != null ? mc.group(1) : mc.group(2)).replace(",", ""));
        }

        // Year from page context, but also try to detect in item text
        if (year == 0) {
            Matcher my = Pattern.compile("\\b(20\\d{2})\\b").matcher(item.text());
            if (my.find()) year = Integer.parseInt(my.group(1));
        }

        return new AudioEntry(title, genre, type, views, score, comments, year, url);
    }

    // -----------------------------------------------------------------------
    private static int parseIntSafe(String s) {
        try { return (int) Double.parseDouble(s.replaceAll("[^\\d.]", "")); }
        catch (Exception e) { return 0; }
    }
    private static float parseFloatSafe(String s) {
        try { return Float.parseFloat(s.replaceAll("[^\\d.]", "")); }
        catch (Exception e) { return 0f; }
    }
}
