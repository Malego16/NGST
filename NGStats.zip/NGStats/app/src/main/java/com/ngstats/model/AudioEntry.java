package com.ngstats.model;

public class AudioEntry {
    public String title;
    public String genre;
    public String type;       // Song / Loop / etc.
    public int views;
    public float score;       // rating 0-5
    public int comments;
    public int year;
    public String url;

    public AudioEntry(String title, String genre, String type,
                      int views, float score, int comments, int year, String url) {
        this.title    = title;
        this.genre    = genre;
        this.type     = type;
        this.views    = views;
        this.score    = score;
        this.comments = comments;
        this.year     = year;
        this.url      = url;
    }

    @Override
    public String toString() {
        return title + " (" + year + ") — " + views + " views, score=" + score;
    }
}
