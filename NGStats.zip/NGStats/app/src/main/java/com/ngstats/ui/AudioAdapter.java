package com.ngstats.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ngstats.R;
import com.ngstats.model.AudioEntry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AudioAdapter extends RecyclerView.Adapter<AudioAdapter.VH> {

    public enum SortColumn { TITLE, VIEWS, SCORE, COMMENTS, YEAR }

    private List<AudioEntry> data    = new ArrayList<>();
    private SortColumn       sortCol = SortColumn.VIEWS;
    private boolean          ascending = false;

    // Which columns to show
    public boolean showTitle    = true;
    public boolean showViews    = true;
    public boolean showScore    = true;
    public boolean showComments = true;
    public boolean showYear     = true;
    public boolean showGenre    = false;

    public void setData(List<AudioEntry> entries) {
        this.data = new ArrayList<>(entries);
        sort();
    }

    public void sortBy(SortColumn col) {
        if (sortCol == col) ascending = !ascending;
        else { sortCol = col; ascending = false; }
        sort();
    }

    private void sort() {
        Comparator<AudioEntry> cmp;
        switch (sortCol) {
            case TITLE:    cmp = Comparator.comparing(e -> e.title);    break;
            case SCORE:    cmp = Comparator.comparingDouble(e -> e.score);   break;
            case COMMENTS: cmp = Comparator.comparingInt(e -> e.comments);   break;
            case YEAR:     cmp = Comparator.comparingInt(e -> e.year);       break;
            default:       cmp = Comparator.comparingInt(e -> e.views);      break;
        }
        if (!ascending) cmp = cmp.reversed();
        Collections.sort(data, cmp);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_audio_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        AudioEntry e = data.get(pos);
        int bg = (pos % 2 == 0) ? Color.parseColor("#1A1A2E") : Color.parseColor("#16213E");
        h.itemView.setBackgroundColor(bg);

        setText(h.tvTitle,    showTitle    ? e.title : null);
        setText(h.tvViews,    showViews    ? String.valueOf(e.views) : null);
        setText(h.tvScore,    showScore    ? String.format("%.2f", e.score) : null);
        setText(h.tvComments, showComments ? String.valueOf(e.comments) : null);
        setText(h.tvYear,     showYear     ? String.valueOf(e.year) : null);
        setText(h.tvGenre,    showGenre    ? e.genre : null);
    }

    private void setText(TextView tv, String val) {
        if (val == null) { tv.setVisibility(View.GONE); return; }
        tv.setVisibility(View.VISIBLE);
        tv.setText(val);
    }

    @Override public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvViews, tvScore, tvComments, tvYear, tvGenre;
        VH(View v) {
            super(v);
            tvTitle    = v.findViewById(R.id.tv_title);
            tvViews    = v.findViewById(R.id.tv_views);
            tvScore    = v.findViewById(R.id.tv_score);
            tvComments = v.findViewById(R.id.tv_comments);
            tvYear     = v.findViewById(R.id.tv_year);
            tvGenre    = v.findViewById(R.id.tv_genre);
        }
    }
}
