package com.ngstats.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ngstats.R;
import com.ngstats.service.FloatingWindowService;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_OVERLAY = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnStart = findViewById(R.id.btn_start);
        TextView tvInfo = findViewById(R.id.tv_info);

        updateInfo(tvInfo);

        btnStart.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                launchService();
            } else {
                requestOverlayPermission();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView tvInfo = findViewById(R.id.tv_info);
        if (tvInfo != null) updateInfo(tvInfo);
    }

    private void updateInfo(TextView tv) {
        if (Settings.canDrawOverlays(this)) {
            tv.setText("✅ Разрешение на оверлей выдано.\nНажмите кнопку чтобы запустить окно статистики.");
        } else {
            tv.setText("⚠️ Для работы приложения необходимо разрешение на отображение поверх других окон.\nНажмите кнопку ниже, чтобы выдать разрешение.");
        }
    }

    private void requestOverlayPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(i, REQ_OVERLAY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                launchService();
            } else {
                Toast.makeText(this, "Разрешение не выдано — оверлей не работает", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void launchService() {
        Intent i = new Intent(this, FloatingWindowService.class);
        startForegroundService(i);
        Toast.makeText(this, "Окно статистики запущено!", Toast.LENGTH_SHORT).show();
        // Minimise app so overlay is visible
        moveTaskToBack(true);
    }
}
