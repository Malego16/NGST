package com.ngstats.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Computes aggregate statistics from a list of AudioEntry objects.
 */
public class StatsCalculator {

    public static class Summary {
        public int   trackCount;
        public long  totalViews;
        public long  totalComments;
        public float avgScore;
        public float maxScore;
        public String topTitle;
        public int   topViews;

        @Override
        public String toString() {
            return "Треков: " + trackCount
                 + "\nПросмотров: " + totalViews
                 + "\nКомментариев: " + totalComments
                 + "\nСредний рейтинг: " + String.format("%.2f", avgScore)
                 + "\nЛучший рейтинг: "  + String.format("%.2f", maxScore)
                 + (topTitle != null ? "\nТоп трек: " + topTitle + " (" + topViews + " views)" : "");
        }
    }

    /** Filter list by year (0 = all years). */
    public static List<AudioEntry> filterByYear(List<AudioEntry> entries, int year) {
        if (year <= 0) return entries;
        List<AudioEntry> out = new ArrayList<>();
        for (AudioEntry e : entries) if (e.year == year) out.add(e);
        return out;
    }

    /** Filter list by year range. */
    public static List<AudioEntry> filterByYearRange(List<AudioEntry> entries, int fromYear, int toYear) {
        List<AudioEntry> out = new ArrayList<>();
        for (AudioEntry e : entries) if (e.year >= fromYear && e.year <= toYear) out.add(e);
        return out;
    }

    public static Summary compute(List<AudioEntry> entries) {
        Summary s = new Summary();
        s.trackCount = entries.size();
        if (entries.isEmpty()) return s;

        long   sumViews    = 0;
        long   sumComments = 0;
        double sumScore    = 0;
        float  maxScore    = 0;
        String topTitle    = null;
        int    topViews    = 0;

        for (AudioEntry e : entries) {
            sumViews    += e.views;
            sumComments += e.comments;
            sumScore    += e.score;
            if (e.score > maxScore) { maxScore = e.score; }
            if (e.views > topViews) { topViews = e.views; topTitle = e.title; }
        }

        s.totalViews    = sumViews;
        s.totalComments = sumComments;
        s.avgScore      = (float)(sumScore / entries.size());
        s.maxScore      = maxScore;
        s.topTitle      = topTitle;
        s.topViews      = topViews;
        return s;
    }

    /** Collect distinct years present in the list. */
    public static List<Integer> distinctYears(List<AudioEntry> entries) {
        List<Integer> years = new ArrayList<>();
        for (AudioEntry e : entries) {
            if (e.year > 0 && !years.contains(e.year)) years.add(e.year);
        }
        years.sort((a, b) -> b - a); // newest first
        return years;
    }
}
